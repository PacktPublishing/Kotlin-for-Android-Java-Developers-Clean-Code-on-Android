The challenges are numbered like the videos, and should directly follow the video with the same number.

For example: 40.60.Challenge should directly *follow* video 40.60.xxx

For video 30.90., there are two challenges that should directly follow each other.